/*

   random.h

   Copyright (c) Michael Strickland

   GNU General Public License (GPLv3)
   See detailed text in license directory

*/

#ifndef __random_h__
#define __random_h__

double randGauss(double s);

#endif /* __random_h__ */
