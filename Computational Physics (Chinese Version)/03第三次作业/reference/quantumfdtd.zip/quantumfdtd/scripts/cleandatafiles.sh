#!/bin/sh

rm -rf data/*.*
rm -rf data/snapshot/*.*
rm -rf debug/*.*
#rm *.log
#rm *.out
