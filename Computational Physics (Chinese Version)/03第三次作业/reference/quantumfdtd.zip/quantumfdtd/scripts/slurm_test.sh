#!/bin/bash
#
# job name:
#SBATCH --job-name=test
#SBATCH --nodes=8
#SBATCH --overcommit
#
#SBATCH -n 65
sleep 30
